import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

#Carga del archivo
data_carros = pd.read_csv("../Datasets/Car_Price_Prediction/CarPrice_Assignment.csv")

#Selección de caracteristicas significativas
caracteristicas_coche = ['wheelbase', 'carlength', 'carwidth', 'carheight', 'horsepower']

#Definición de variables dependientes e independientes
X_carros = data_carros[caracteristicas_coche]
y_carros = data_carros["price"]

#Carga del archivo
data_vino = pd.read_csv("../Datasets/Wine_Quality/winequality-red.csv", sep=';')

#Selección de caracteristicas significativas
caracteristicas_vino = ['fixed acidity', 'residual sugar', 'density', 'pH', 'alcohol']

#Definición de variables dependientes e independientes
X_vino = data_vino[caracteristicas_vino]
y_vino = data_vino["quality"]


def evaluar_modelos(X, y, dataset):

    #Dividir los datos en conjunto de entrenamiento y prueba
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)
    model = LinearRegression()

    #Entrenamiento del modelo
    model.fit(X_train, y_train)

    #Se obtiene el score del modelo
    score = model.score(X_test, y_test)
    print(f"Parametro R^2 del dataset {dataset}: {score:.4f}")
    return model

def generar_coche_aleatorio():
    return {
        'wheelbase': np.random.uniform(85, 120),
        'carlength': np.random.uniform(150, 200),
        'carwidth': np.random.uniform(60, 75),
        'carheight': np.random.uniform(45, 60),
        'horsepower': np.random.randint(70, 300)
    }

def generar_vino_aleatorio():
    return {
        'fixed acidity': np.random.uniform(4.0, 16.0),
        'residual sugar': np.random.uniform(0.5, 15.0),
        'density': np.random.uniform(0.990, 1.005),
        'pH': np.random.uniform(2.8, 4.0),
        'alcohol': np.random.uniform(8.0, 15.0)
    }

modelo_carros = evaluar_modelos(X_carros, y_carros, "Car Price Prediction")
modelo_vinos = evaluar_modelos(X_vino, y_vino, "Wine Quality")

nuevo_coche = generar_coche_aleatorio()
nuevo_vino = generar_vino_aleatorio()

#Crear DataFrame para la predicción
nuevo_vino_df = pd.DataFrame([nuevo_vino])[caracteristicas_vino]
nuevo_coche_df = pd.DataFrame([nuevo_coche])[caracteristicas_coche]

#Realizar predicciones
precio_coche = modelo_carros.predict(nuevo_coche_df)
calidad_vino = modelo_vinos.predict(nuevo_vino_df)

#print("Nuevo coche generado:", nuevo_coche)
#print("Nuevo vino generado:", nuevo_vino)

print(f"El precio estimado del siguiente auto es: ${precio_coche[0]:.2f}")
print(f'La calidad estimada del siguiente vino es: {calidad_vino[0]:.2f}')
