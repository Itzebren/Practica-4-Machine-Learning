import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

#Carga del archivo
data_carros = pd.read_csv("../Datasets/Car_Price_Prediction/CarPrice_Assignment.csv")

#Selección de caracteristicas significativas
caracteristicas_coche = ['wheelbase', 'carlength', 'carwidth', 'carheight', 'horsepower']

#Definición de variables dependientes e independientes
X_carros = data_carros[caracteristicas_coche]
y_carros = data_carros["price"]

#Carga del archivo
data_vino = pd.read_csv("../Datasets/Wine_Quality/winequality-red.csv", sep=';')

#Selección de caracteristicas significativas
caracteristicas_vino = ['fixed acidity', 'residual sugar', 'density', 'pH', 'alcohol']

#Definición de variables dependientes e independientes
X_vino = data_vino[caracteristicas_vino]
y_vino = data_vino["quality"]

def encontrar_mejor_rf(X, y, dataset_name):

    #Dividir los datos en conjunto de entrenamiento y prueba
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)
    
    #Metricas para almacenar el mejor modelo
    best_score = -1
    best_n_estimators = 100
    best_model = None
    
    #Probar diferentes números de árboles
    n_estimators_list = [50, 100, 200, 300]
    
    #Bucle para encontrar el mejor número de árboles
    for n_estimators in n_estimators_list:
        model = RandomForestRegressor(
            n_estimators=n_estimators,
            random_state=42,
            n_jobs=-1
        )

        #Entrenamiento del modelo
        model.fit(X_train, y_train)

        #Se obtiene el score del modelo
        score = model.score(X_test, y_test)
        
        print(f"{dataset_name} - n_estimators={n_estimators}: R² = {score:.4f}")
        
        #Condición para actualizar el mejor modelo
        if score > best_score:
            best_score = score
            best_n_estimators = n_estimators
            best_model = model
    
    print(f"Mejor para el dataset {dataset_name}: n_estimators={best_n_estimators}, R²={best_score:.4f}\n")
    return best_model, best_n_estimators, best_score

def generar_coche_aleatorio():
    return {
        'wheelbase': np.random.uniform(85, 120),
        'carlength': np.random.uniform(150, 200),
        'carwidth': np.random.uniform(60, 75),
        'carheight': np.random.uniform(45, 60),
        'horsepower': np.random.randint(70, 300)
    }

def generar_vino_aleatorio():
    return {
        'fixed acidity': np.random.uniform(4.0, 16.0),
        'residual sugar': np.random.uniform(0.5, 15.0),
        'density': np.random.uniform(0.990, 1.005),
        'pH': np.random.uniform(2.8, 4.0),
        'alcohol': np.random.uniform(8.0, 15.0)
    }

modelo_carros_rf, best_n_carros, score_carros = encontrar_mejor_rf(X_carros, y_carros, "Car Price Prediction")
modelo_vinos_rf, best_n_vinos, score_vinos = encontrar_mejor_rf(X_vino, y_vino, "Wine Quality")

nuevo_coche = generar_coche_aleatorio()
nuevo_vino = generar_vino_aleatorio()

#print("Coche generado:", nuevo_coche)
#print("Vino generado:", nuevo_vino)

#Generar DataFrame para la predicción
nuevo_coche_df = pd.DataFrame([nuevo_coche])[caracteristicas_coche]
nuevo_vino_df = pd.DataFrame([nuevo_vino])[caracteristicas_vino]

#Realizar predicciones
precio_coche_rf = modelo_carros_rf.predict(nuevo_coche_df)
calidad_vino_rf = modelo_vinos_rf.predict(nuevo_vino_df)

print(f"Precio estimado del auto: ${precio_coche_rf[0]:.2f}")
print(f"Calidad estimada del vino: {calidad_vino_rf[0]:.2f}")