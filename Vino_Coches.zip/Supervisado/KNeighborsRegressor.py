import pandas as pd
import numpy as np
from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

#Carga del archivo
data_carros = pd.read_csv("../Datasets/Car_Price_Prediction/CarPrice_Assignment.csv")

#Selección de caracteristicas significativas
caracteristicas_coche = ['wheelbase', 'carlength', 'carwidth', 'carheight', 'horsepower']

#Definición de variables dependientes e independientes
X_carros = data_carros[caracteristicas_coche]
y_carros = data_carros["price"]

#Carga del archivo
data_vino = pd.read_csv("../Datasets/Wine_Quality/winequality-red.csv", sep=';')

#Selección de caracteristicas significativas
caracteristicas_vino = ['fixed acidity', 'residual sugar', 'density', 'pH', 'alcohol']

#Definición de variables dependientes e independientes
X_vino = data_vino[caracteristicas_vino]
y_vino = data_vino["quality"]

#Estandarización de los datos
scaler_coche = StandardScaler()
scaler_vino = StandardScaler()

#Transformación de los datos
X_carros_scaled = scaler_coche.fit_transform(X_carros)
X_vino_scaled = scaler_vino.fit_transform(X_vino)

def evaluar_modelos_knn(X, y, dataset, scaler):

    #Dividir los datos en conjunto de entrenamiento y prueba
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)
    
    #Metricas para almacenar el mejor modelo
    best_score = -1
    best_k = 1
    
    for k in [3, 5, 7, 9, 11]:
        model = KNeighborsRegressor(n_neighbors=k)

        #Entrenamiento del modelo
        model.fit(X_train, y_train)

        #Se obtiene el score del modelo
        score = model.score(X_test, y_test)
        
        if score > best_score:
            best_score = score
            best_k = k
            best_model = model
    
    print(f"Mejor K para {dataset}: k={best_k}, R²: {best_score:.4f}")
    return best_model, scaler

def generar_coche_aleatorio():
    return {
        'wheelbase': np.random.uniform(85, 120),
        'carlength': np.random.uniform(150, 200),
        'carwidth': np.random.uniform(60, 75),
        'carheight': np.random.uniform(45, 60),
        'horsepower': np.random.randint(70, 300)
    }

def generar_vino_aleatorio():
    return {
        'fixed acidity': np.random.uniform(4.0, 16.0),
        'residual sugar': np.random.uniform(0.5, 15.0),
        'density': np.random.uniform(0.990, 1.005),
        'pH': np.random.uniform(2.8, 4.0),
        'alcohol': np.random.uniform(8.0, 15.0)
    }

modelo_carros_knn, scaler_coche = evaluar_modelos_knn(X_carros_scaled, y_carros, "Car Price Prediction", scaler_coche)
modelo_vinos_knn, scaler_vino = evaluar_modelos_knn(X_vino_scaled, y_vino, "Wine Quality", scaler_vino)

nuevo_coche = generar_coche_aleatorio()
nuevo_vino = generar_vino_aleatorio()

#print("Coche generado:", nuevo_coche)
#print("Vino generado:", nuevo_vino)

#Creación de DataFrame para el nuevo coche y vino
nuevo_coche_df = pd.DataFrame([nuevo_coche])[caracteristicas_coche]
nuevo_vino_df = pd.DataFrame([nuevo_vino])[caracteristicas_vino]

#Estandarización de los nuevos datos
nuevo_coche_scaled = scaler_coche.transform(nuevo_coche_df)
nuevo_vino_scaled = scaler_vino.transform(nuevo_vino_df)

#Predicción de precio y calidad
precio_coche_knn = modelo_carros_knn.predict(nuevo_coche_scaled)
calidad_vino_knn = modelo_vinos_knn.predict(nuevo_vino_scaled)

print(f"Precio estimado del auto: ${precio_coche_knn[0]:.2f}")
print(f"Calidad estimada del vino: {calidad_vino_knn[0]:.2f}")